package com.yorg.mownit.lab3.utils;

/**
 * Created by yorg on 01.04.15.
 */
public interface Stopper {

    public boolean shouldStop(double x1, double x2, double functionValue, int iterationNumber);

}
