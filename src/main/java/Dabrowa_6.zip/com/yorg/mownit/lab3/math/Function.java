package com.yorg.mownit.lab3.math;

public interface Function<T> {

    T getValue(double x);

}
