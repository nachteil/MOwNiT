package com.yorg.mownit.lab4.polynomial;

public interface Function {

    public double getValue(double argument);

}
