package com.yorg.mownit.commons;

public class Range {

    public Range(double start, double end) {
        this.start = start;
        this.end = end;
    }

    public final double start;
    public final double end;
}
