package com.yorg.mownit.lab2;

/**
* Created by yorg on 25.03.15.
*/
public enum MatrixElementType {
    A, B, type, C
}
