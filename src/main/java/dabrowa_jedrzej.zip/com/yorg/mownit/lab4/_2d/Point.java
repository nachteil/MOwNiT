package com.yorg.mownit.lab4._2d;

import lombok.Getter;

public class Point {

    @Getter double x;
    @Getter double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

}
