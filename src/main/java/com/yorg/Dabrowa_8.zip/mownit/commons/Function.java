package com.yorg.mownit.commons;

public interface Function {
    double getValue(double x);
}
