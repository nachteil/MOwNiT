package com.yorg.mownit.commons.functioncomp;

import com.yorg.mownit.commons.Function;

public interface FunctionComparator {

    double compare(Function a, Function b);

}
