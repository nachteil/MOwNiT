package com.yorg.mownit.lab1;

public class Lab1Main {

    public static void main(String[] args) throws InterruptedException {

        new Lab1Runner().runThirdExerciseTriDiag();
        new Lab1Runner().runThirdExerciseGauss();

    }

}
