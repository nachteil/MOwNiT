package com.yorg.mownit.lab8;

public interface DERightSideFunction {

    double getVal(double x, double y);

}
