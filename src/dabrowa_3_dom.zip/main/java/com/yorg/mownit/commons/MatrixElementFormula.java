package com.yorg.mownit.commons;

public interface MatrixElementFormula {
    double getElement(int row, int col);
}
